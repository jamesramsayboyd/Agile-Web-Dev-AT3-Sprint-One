<!DOCTYPE html>

<!--
 * Zac Purkiss 
 * P444025
 * 09.08.2022
-->
 
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<title>Index</title>
	<link rel="stylesheet" type="text/css" href="index_files/style.css">
	<meta charset="utf-8">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>

<body>

	<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">ACME Arts</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="#">Index</a></li>
      <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">Artists
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="#">All</a></li>
          <li><a href="#">Artist 1</a></li>
          <li><a href="#">Artist 2</a></li>
        </ul>
      </li><li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">Styles
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="#">All</a></li>
          <li><a href="#">Style 1</a></li>
          <li><a href="#">Style 2</a></li>
        </ul>
      </li>
    </ul>
    <form class="navbar-form navbar-left" action="/action_page.php">
      <div class="form-group">
        <input type="text" class="form-control" placeholder="Search">
      </div>
      <button type="submit" class="btn btn-default">Submit</button>
    </form>
  </div>
</nav>
	
	<div class="container">
	  <table class="table">
	    <thead>
		  <th>ID</th>
		  <th>Image</th>
		  <th>Title</th>
		  <th>Year</th>
		  <th>Media</th>
		  <th>Artist</th>
		  <th>Style</th>
	    </thead>
		<tbody>
		  <?php
		    include_once('connection.php');

			$database = new Connection();
    		$db = $database->open();
			try{	
			  $sql = 'SELECT * FROM content WHERE id = 1';
			  foreach ($db->query($sql) as $row) {
		  ?>
		  <tr>
			<td><?php echo $row['id']; ?></td>
			<td><?php echo $row['image']; ?></td>
			<td><?php echo $row['title']; ?></td><td><?php echo $row['question']; ?></td>
			<td><?php echo $row['year']; ?></td>
			<td><?php echo $row['media']; ?></td><td><?php echo $row['question']; ?></td>
			<td><?php echo $row['artist']; ?></td>
			<td><?php echo $row['style']; ?></td>
		  </tr>
		  <?php 
			  }
			}
			catch(PDOException $e){
			  echo "'ruh roh' - scooby doo";
			}

			$database->close();

			  ?>
		</tbody>
	  </table>
	</div>
</body>
</html>