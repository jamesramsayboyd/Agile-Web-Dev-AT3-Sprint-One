<!DOCTYPE html>

<!--
 * Zac Purkiss 
 * P444025
 * 09.08.2022
-->
 
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<title>Index</title>
	<link rel="stylesheet" type="text/css" href="index_files/style.css">
	<meta charset="utf-8">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>

<body>

	<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">ACME Arts</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="#">Index</a></li>
      <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">Artists
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="#">All</a></li>
          <li><a href="#">Artist 1</a></li>
          <li><a href="#">Artist 2</a></li>
        </ul>
      </li><li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">Styles
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="#">All</a></li>
          <li><a href="#">Style 1</a></li>
          <li><a href="#">Style 2</a></li>
        </ul>
      </li>
    </ul>
    <form class="navbar-form navbar-left" action="/action_page.php">
      <div class="form-group">
        <input type="text" class="form-control" placeholder="Search">
      </div>
      <button type="submit" class="btn btn-default">Submit</button>
    </form>
  </div>
</nav>
	
	<div id="colbox">
		<div class="panel-body">
		ACME Arts Homepage
		<br>Names..
		<br>IDs..
		<br>Assessment ID..
		</div>
	</div>
</body>
</html>